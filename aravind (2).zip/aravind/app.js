const express = require('express');
const fs = require('fs');

const app = express();
const PORT = 3000;

// Middleware to parse JSON bodies
app.use(express.json());
// Serve static files from the public directory
app.use(express.static('public'));

// Load existing devices from devices.json into memory on application startup
let devices = loadDevices();

// Device Registration
app.post('/register', (req, res) => {
    const { deviceId, deviceType, value, command } = req.body;

    if (!deviceId || !deviceType) {
        return res.status(400).json({ error: 'deviceId and deviceType are required' });
    }

    const device = { deviceId, deviceType, value, command };
    devices.push(device);

    saveDevices(devices);

    res.status(201).json({ message: 'Device registered successfully' });
});

// Displaying Devices
app.get('/show', (req, res) => {
    res.json(devices);
});

// Receiving Device Data
app.post('/data', (req, res) => {
    const { dataDeviceId, data } = req.body;
    // Check if dataDeviceId and value are present in the request body
    if (!dataDeviceId || !data) {
        return res.status(400).json({ error: 'deviceId and value are required' });
    }
    // Log the received data with a timestamp
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp}: Received data from device ${dataDeviceId}: ${data}`;
    logData(logMessage);

    // Update the value of the corresponding device in devices.json
    updateDeviceValue(dataDeviceId, data);

    res.status(200).json({ message: 'Data received successfully' });
});

// Function to update the value of the corresponding device in devices.json
function updateDeviceValue(deviceId, value) {
    try {
        const devicesData = JSON.parse(fs.readFileSync('devices.json', 'utf8'));
        const updatedDevices = devicesData.map(device => {
            if (device.deviceId === deviceId) {
                device.value = value; // Update the value property
            }
            return device;
        });

        fs.writeFileSync('devices.json', JSON.stringify(updatedDevices, null, 2));
    } catch (error) {
        console.error('Error updating device value:', error);
    }
}


// Sending Commands to Devices
app.post('/command', (req, res) => {
    const { commandDeviceId, command } = req.body;

    if (!commandDeviceId || !command) {
        return res.status(400).json({ error: 'deviceId and command are required' });
    }

    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp}: Command sent to device ${commandDeviceId}: ${command}`;
    logData(logMessage);
    updateCommandValue(commandDeviceId, command);
    res.status(200).json({ message: 'Command sent successfully' });
});

function updateCommandValue(deviceId, command) {
    try {
        const devicesData = JSON.parse(fs.readFileSync('devices.json', 'utf8'));
        const updatedDevices = devicesData.map(device => {
            if (device.deviceId === deviceId) {
                device.command = command; // Update the value property
            }
            return device;
        });

        fs.writeFileSync('devices.json', JSON.stringify(updatedDevices, null, 2));
    } catch (error) {
        console.error('Error updating device value:', error);
    }
}

// Logging function
function logData(message) {
    const timestamp = new Date().toISOString();
    const logMessage = `${timestamp}: ${message}\n`;

    fs.appendFile('logs.txt', logMessage, err => {
        if (err) {
            console.error(err);
        }
    });
}

// Load existing devices from devices.json into memory on application startup
function loadDevices() {
    try {
        const data = fs.readFileSync('devices.json', 'utf8');
        return JSON.parse(data) || [];
    } catch (error) {
        console.error(error);
        return []; // Return an empty array in case of error
    }
}


// Save devices to devices.json
function saveDevices(devices) {
    fs.writeFile('devices.json', JSON.stringify(devices, null, 2), err => {
        if (err) {
            console.error(err);
        }
    });
}

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
