document.addEventListener('DOMContentLoaded', () => {
    const registerForm = document.getElementById('registerForm');
    const dataForm = document.getElementById('dataForm');
    const commandForm = document.getElementById('commandForm');
    const responseMessage = document.getElementById('responseMessage');

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(registerForm);
        const responseData = await postData('/register', formData);
        responseMessage.innerText = responseData.message;
    });

    dataForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(dataForm);
        const responseData = await postData('/data', formData);
        responseMessage.innerText = responseData.message;
    });

    commandForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const formData = new FormData(commandForm);
        const responseData = await postData('/command', formData);
        responseMessage.innerText = responseData.message;
    });

    async function postData(url = '', data = {}) {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(Object.fromEntries(data))
        });
        return response.json();
    }
});
